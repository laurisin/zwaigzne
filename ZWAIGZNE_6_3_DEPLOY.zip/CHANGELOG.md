# ZWAIGZNE 6.3 changelog

- Maintenance-only release from 6.2.
- Moved the existing final CSS override block inside the HTML document, before `</body>` and `</html>`, for valid document structure.
- Updated version labels to 6.3.
- No intentional changes to audio/DSP logic, routing, controls, or patch compatibility.
