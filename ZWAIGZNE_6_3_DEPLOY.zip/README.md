# ZWAIGZNE 6.3 — Maintenance release

This is a small maintenance release based on 6.2.

## Changes
- Consolidated the final responsive/navigation/Flow/Oracle/Chambers CSS overrides into the HTML document before the closing body tag, rather than leaving a style element after the closing HTML tag.
- Updated the visible/document version references from 6.2 to 6.3.
- No audio engine, synthesis, signal-routing, patch format, or DSP behavior was intentionally changed.

## Deployment
Upload this ZIP to the repository root as expected by the ZIP-triggered GitHub Actions workflow. Do not unzip it on Android. The workflow must already be configured to detect root-level ZIP uploads, extract the archive, and publish the `index.html` it finds.
